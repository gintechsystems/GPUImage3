public class LinearBurnBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"linearBurnBlendFragment", numberOfInputs:2)
    }
}
