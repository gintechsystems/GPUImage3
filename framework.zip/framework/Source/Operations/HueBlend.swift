public class HueBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"hueBlendFragment", numberOfInputs:2)
    }
}
