public class OverlayBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"overlayBlendFragment", numberOfInputs:2)
    }
}
