public class Luminance: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"luminanceFragment", numberOfInputs:1)
    }
}
