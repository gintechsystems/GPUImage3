public class AddBlend: BasicOperation {
    
    public init() {
        super.init(fragmentFunctionName:"addBlendFragment", numberOfInputs:2)
    }
}
