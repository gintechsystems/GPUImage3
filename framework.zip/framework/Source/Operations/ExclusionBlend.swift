public class ExclusionBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"exclusionBlendFragment", numberOfInputs:2)
    }
}
