public class ColorBurnBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"colorBurnBlendFragment", numberOfInputs:2)
    }
}
