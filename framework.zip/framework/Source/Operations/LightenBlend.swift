public class LightenBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"lightenBlendFragment", numberOfInputs:2)
    }
}
