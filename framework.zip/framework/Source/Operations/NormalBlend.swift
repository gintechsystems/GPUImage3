public class NormalBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"normalBlendFragment", numberOfInputs:2)
    }
}
