public class MedianFilter: TextureSamplingOperation {
    public init() {
        super.init(fragmentFunctionName:"medianFilter")
    }
}
