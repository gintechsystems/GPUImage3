public class Laplacian: TextureSamplingOperation {
    public init() {
        super.init(fragmentFunctionName:"laplacianFilter")        
    }
}
