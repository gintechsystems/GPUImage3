public class CGAColorspaceFilter: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"CGAColorspaceFragment", numberOfInputs:1)
    }
}
