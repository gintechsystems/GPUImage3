public class DifferenceBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"differenceBlendFragment", numberOfInputs:2)
    }
}
