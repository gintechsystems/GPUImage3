public class ColorDodgeBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"colorDodgeBlendFragment", numberOfInputs:2)
    }
}
