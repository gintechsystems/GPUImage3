public class DivideBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName: "divideBlendFragment", numberOfInputs:2)
    }
}
