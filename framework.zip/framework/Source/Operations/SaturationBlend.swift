public class SaturationBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"saturationBlendFragment", numberOfInputs:2)
    }
}
