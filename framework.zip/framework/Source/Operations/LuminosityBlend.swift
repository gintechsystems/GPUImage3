public class LuminosityBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"luminosityBlendFragment", numberOfInputs:2)
    }
}
