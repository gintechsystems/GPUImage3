public class ScreenBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"screenBlendFragment", numberOfInputs:2)
    }
}
