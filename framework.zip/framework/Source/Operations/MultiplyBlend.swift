public class MultiplyBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"multiplyBlendFragment", numberOfInputs:2)
    }
}
