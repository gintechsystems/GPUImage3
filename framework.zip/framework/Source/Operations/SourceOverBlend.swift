public class SourceOverBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"sourceOverBlendFragment", numberOfInputs:2)
    }
}
