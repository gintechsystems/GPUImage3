public class KuwaharaRadius3Filter: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"kuwaharaRadius3Fragment", numberOfInputs:1)
    }
}
