public class DarkenBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"darkenBlendFragment", numberOfInputs:2)
    }
}
