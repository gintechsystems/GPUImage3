public class SoftLightBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"softLightBlendFragment", numberOfInputs:2)
    }
}
