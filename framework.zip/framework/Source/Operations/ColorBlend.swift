public class ColorBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"colorBlendFragment", numberOfInputs:2)
    }
}
