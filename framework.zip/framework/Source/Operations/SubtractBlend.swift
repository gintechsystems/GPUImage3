public class SubtractBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"subtractBlendFragment", numberOfInputs:2)
    }
}
