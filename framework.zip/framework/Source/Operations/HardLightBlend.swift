public class HardLightBlend: BasicOperation {
    public init() {
        super.init(fragmentFunctionName:"hardLightBlendFragment", numberOfInputs:2)
    }
}
